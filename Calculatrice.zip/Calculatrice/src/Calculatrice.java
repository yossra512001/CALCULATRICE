import java.awt.*;
import java.awt.event.*;

public class Calculatrice extends Frame implements ActionListener {
	Button b0 = new Button("7");
	Button b1 = new Button("8");
	Button b2 = new Button("9");
	Button b3 = new Button("4");
	Button b4 = new Button("5");
	Button b5 = new Button("6");
	Button b6 = new Button("1");
	Button b7 = new Button("2");
	Button b8 = new Button("3");
	Button b9 = new Button("0");
	Button b10 = new Button("+/-");
	Button b11 = new Button("ClearAll");
	Button b12 = new Button("+");
	Button b13 = new Button("-");
	Button b14 = new Button("*");
	Button b15 = new Button("/");
	Button b = new Button("Enter");
	TextField ta = new TextField();
	int cal;
	String s1, s2, s3, s12;

	Calculatrice() {
		setLayout(new BorderLayout());
		setSize(300, 300);
		this.setTitle("Calculatrice");
		Panel P1 = new Panel();
		Panel p0 = new Panel();
		ta.setColumns(180);
		ta.setText("0");
		p0.add(ta);
		add(p0, "North");
		Panel p1 = new Panel();
		Panel p2 = new Panel();
		b.addActionListener(this);
		b.setForeground(Color.green);
		b.setPreferredSize(new Dimension(1200, 20));
		p2.add(b);
		add(p2, "South");
		b0.setForeground(Color.blue);
		b1.setForeground(Color.blue);
		b2.setForeground(Color.blue);
		b3.setForeground(Color.blue);
		b4.setForeground(Color.blue);
		b5.setForeground(Color.blue);
		b6.setForeground(Color.blue);
		b7.setForeground(Color.blue);
		b8.setForeground(Color.blue);
		b9.setForeground(Color.blue);
		b11.setForeground(Color.pink);
		b12.setForeground(Color.red);
		b13.setForeground(Color.red);
		b14.setForeground(Color.red);
		b15.setForeground(Color.red);

		b0.addActionListener(this);
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
		b4.addActionListener(this);
		b5.addActionListener(this);
		b6.addActionListener(this);
		b7.addActionListener(this);
		b8.addActionListener(this);
		b9.addActionListener(this);
		b10.addActionListener(this);
		b11.addActionListener(this);
		addWindowListener(new Fermer());
		b12.addActionListener(this);
		b13.addActionListener(this);
		b14.addActionListener(this);
		b15.addActionListener(this);
		b.addActionListener(this);

		p1.add(b12);
		p1.add(b13);
		p1.add(b14);
		p1.add(b15);
		P1.add(b0);
		P1.add(b1);
		P1.add(b2);
		P1.add(b3);
		P1.add(b4);
		P1.add(b5);
		P1.add(b6);
		P1.add(b7);
		P1.add(b8);
		P1.add(b9);
		P1.add(b10);
		P1.add(b11);
		p1.add(b12);
		p1.add(b13);
		p1.add(b14);
		p1.add(b15);
		P1.setLayout(new GridLayout(4, 3));
		p1.setLayout(new GridLayout(4, 1));
		add(P1, "Center");
		add(p1, "East");
		pack();
		setVisible(true);
	}

	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == b9) {
			s1 = ta.getText();
			s2 = "0";
			s3 = s1 + s2;
			ta.setText(s3);
		}
		if (e.getSource() == b0) {
			s1 = ta.getText();
			s2 = "7";
			s3 = s1 + s2;
			ta.setText(s3);
		}
		if (e.getSource() == b1) {
			s1 = ta.getText();
			s2 = "8";
			s3 = s1 + s2;
			ta.setText(s3);
		}
		if (e.getSource() == b2) {
			s1 = ta.getText();
			s2 = "9";
			s3 = s1 + s2;
			ta.setText(s3);
		}
		if (e.getSource() == b3) {
			s1 = ta.getText();
			s2 = "4";
			s3 = s1 + s2;
			ta.setText(s3);
		}
		if (e.getSource() == b4) {
			s1 = ta.getText();
			s2 = "5";
			s3 = s1 + s2;
			ta.setText(s3);
		}
		if (e.getSource() == b5) {
			s1 = ta.getText();
			s2 = "6";
			s3 = s1 + s2;
			ta.setText(s3);
		}
		if (e.getSource() == b6) {
			s1 = ta.getText();
			s2 = "1";
			s3 = s1 + s2;
			ta.setText(s3);
		}

		if (e.getSource() == b7) {
			s1 = ta.getText();
			s2 = "2";
			s3 = s1 + s2;
			ta.setText(s3);
		}
		if (e.getSource() == b8) {
			s1 = ta.getText();
			s2 = "3";
			s3 = s1 + s2;
			ta.setText(s3);
		}
		if (e.getSource() == b9) {
			s1 = ta.getText();
			s2 = "";
			s3 = s1 + s2;
			ta.setText(s3);
		}
		if (e.getSource() == b12) {
			s12 = ta.getText();
			ta.setText("");
			cal = 1;
		}
		if (e.getSource() == b13) {
			s12 = ta.getText();
			ta.setText("");
			cal = 2;
		}
		if (e.getSource() == b14) {
			s12 = ta.getText();
			ta.setText("");
			cal = 3;
		}
		if (e.getSource() == b15) {
			s12 = ta.getText();
			ta.setText("");
			cal = 4;
		}
		if (e.getSource() == b) {

			if (cal == 1) {
				int res = Integer.valueOf(s3) + Integer.valueOf(s12);
				ta.setText(String.valueOf(res));
			}
			if (cal == 2) {
				int res = Integer.valueOf(s12) - Integer.valueOf(s3);
				ta.setText(String.valueOf(res));
			}
			if (cal == 3) {
				int res = Integer.valueOf(s3) * Integer.valueOf(s12);
				ta.setText(String.valueOf(res));
			}
			if (cal == 4) {
				float res = Float.valueOf(s12) / Float.valueOf(s3);
				ta.setText(String.valueOf(res));
			}
		}

		if (e.getSource() == b11) {
			ta.setText("");
		}

	}

	public static void main(String args[]) {
		Calculatrice c = new Calculatrice();

	}

}
